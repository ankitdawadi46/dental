from django.apps import AppConfig


class DentalPlanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dental_plan'
