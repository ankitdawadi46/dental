from dental_app.wsgi import application

application = application