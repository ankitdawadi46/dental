from rest_framework.routers import DefaultRouter

app_name = "appointments"

router = DefaultRouter()


urlpatterns = router.urls